package com.wishme.bichnali;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BichnaliApplication {

	public static void main(String[] args) {
		SpringApplication.run(BichnaliApplication.class, args);
	}

}
